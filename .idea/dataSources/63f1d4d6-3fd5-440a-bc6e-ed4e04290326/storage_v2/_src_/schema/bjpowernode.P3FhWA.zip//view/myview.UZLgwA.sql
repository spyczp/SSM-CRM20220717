create view myview as
select `bjpowernode`.`emp2`.`EMPNO`    AS `EMPNO`,
       `bjpowernode`.`emp2`.`ENAME`    AS `ENAME`,
       `bjpowernode`.`emp2`.`JOB`      AS `JOB`,
       `bjpowernode`.`emp2`.`MGR`      AS `MGR`,
       `bjpowernode`.`emp2`.`HIREDATE` AS `HIREDATE`,
       `bjpowernode`.`emp2`.`SAL`      AS `SAL`,
       `bjpowernode`.`emp2`.`COMM`     AS `COMM`,
       `bjpowernode`.`emp2`.`DEPTNO`   AS `DEPTNO`
from `bjpowernode`.`emp2`;

